var System = Java.type("java.lang.System");

System.out.print("HTTP/statUs123UNDNUN\r\n\r\n");
System.out.print("Berlin, Berlin ...\r\n");
System.out.flush();
