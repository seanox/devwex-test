var System = Java.type("java.lang.System");

System.out.print("HTTP/1.1 123 Test\r\n");
System.out.print("Server: NoName\r\n");
System.out.print("\r\n");
