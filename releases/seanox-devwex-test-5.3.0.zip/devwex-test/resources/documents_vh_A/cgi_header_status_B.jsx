var System = Java.type("java.lang.System");

System.out.print("HTTP/XXX -444 AAA BBB\r\n\r\n");
System.out.print("Berlin, Berlin ...\r\n");
System.out.flush();
