var System = Java.type("java.lang.System");

while ((digit = System.in.read(bytes)) >= 0)
    volume++;
System.print("\r\n\r\nfailed");
