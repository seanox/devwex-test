var System = Java.type("java.lang.System");

System.out.print("HTTP/1.0 200\r\n");
System.out.print("\r\n");
System.out.print("hallo");
